//Nick Wilmsmeyer & Brandon Olson
//Data Structures Project 1
//Infix Expression Parser
// This project has all implementations except the exact ordering and using multiple character operations, but it has the code to read it and do the math.
// It goes from back to front replacing the top with the result from a round of operation

#include<iostream>
#include<stack>
#include<string>
#include<cmath>
#include <sstream>
using namespace std;
//class to have stacks avaliable
class Evaluator {
public:
	void build();	//builds stack parsing through the string given
	int show();		//does the math and reading through stacks
	stack <int> valStack;	//holds all integers in stack
	stack <string> opStack;	//holds all operands in stack
};

int Evaluator::show() {
	int count = 0;
	int result;
	int big = opStack.size();		//opStack is sized to use in for loop	
	for (int i = 0; i < big; i++) {	//for loop to iterate and pop elements of stacks
		string s = opStack.top();	//reads first operand in stack
		opStack.pop();				//pops top element so we get the otheroperand next round
		char c = s[0];				//builds the switch var
		int a = valStack.top();		//grabs first var in valStack
		valStack.pop();
		
		int b = valStack.top();		//grabs next var in valStack to use in operation
		valStack.pop();

		switch (c) {				//switch to check what kind of math is needed
		case '+':
			result = b + a;			//simple addition
			break;
		case '-':
			result = b - a;			//simple subtration
			break;
		case '*':
			result = b * a;			//simple multiplication
			break;
		case '/':
			if (a == 0) {
				cout << "cant divide by zero! bye";
				system("PAUSE");
				exit(1);
			}
			result = b / a;			//simple division
			break;
		case '%':
			result = b % a;			//modulo of b using a
			break;
		case '--':	
			result = b - 1;			//decrementing b
			break;
		case '++':
			result = b + 1;			//incrementing b
			break;
		case '^':					//exponent a with b
			result = (int)pow((double)b, a);
			break;
		case '||':
			if ((a == 1) || (b == 1))//bool or of a & b
				result = 1;
			else
				result = 0;
			break;
		case '&&':
			if ((a == 1) && (b == 1))//bool and of a & b
				result = 1;
			else
				result = 0;
			break;
		case '==':
			if (a == b)				//bool of equality
				result = 1;
			else
				result = 0;
			break;
		case '!=':
			if (a != b)				//bool of inequality
				result = 1;
			else
				result = 0;
			break;
		case '<':
			if (b < a)				//bool of less than
				result = 1;
			else
				result = 0;
			break;
		case '>':					//bool of greater than
			if (b > a)
				result = 1;
			else
				result = 0;
			break;
		case '<=':
			if (b <= a)				//bool of less than or equal to
				result = 1;
			else
				result = 0;
			break;
		case '>=':
			if (b >= a)				//bool of greater than or equal to
				result = 1;
			else
				result = 0;
			break;
		case '!':
			b = 0;					//bool of falsality
			break;
		default:
			cout << "no operand given where needed, extra number or missing operand";
			system("PAUSE");
			exit(1);
		}
		
		valStack.push(result);		//pushing results to keep going on operation
		count++;
	}
	return valStack.top();			//returning the final result
}

//function to get string and push it all into the stacks depending on what it is
void Evaluator::build() {
	string str = "3^2+2*4";			//string that will be pushed into the stack one char at a time

	for (int i = 0; i < str.length(); i++) {
		if (isdigit(str[i])) {		//for loop to increment through the str of its length and if to check if the wanted char is an int
			if (i != 0) {
				if (isdigit(str[i - 1])) {//error handling for 2 ints in a row
					cout << "you can't have 2 numbers in a row";
					system("PAUSE");
					exit(1);
				}
			}
			int value = str[i];		//converting char to an int so we can do math later out of the stack
			switch (value) {		//switch to check the value of value using pointer locations
			case 48: value = 0; break;
			case 49: value = 1; break;
			case 50: value = 2; break;
			case 51: value = 3; break;
			case 52: value = 4; break;
			case 53: value = 5; break;
			case 54: value = 6; break;
			case 55: value = 7; break;
			case 56: value = 8; break;
			case 57: value = 9; break;
			default: cout << "invalid int inputted"; system("PAUSE"); exit(1); break;
			}
			valStack.push(value);	//pushing the int value into valStack
			cout << valStack.top();	//outputting to see the str input
		}
		else {	
			if (!isdigit(str[i + 1])) {//if to see if its a double character operand or not
				string str1(1, str[i]);//getting str1 to give to join
				string str2(1, str[i + 1]);//getting str2 to give to join
				string join = str1 + str2;//setting join equal to str1 and str2 together
				opStack.push(join);	//pushing the string into the opStack
				if (((opStack.top() != "++") || (opStack.top() != "--")) && (i == 0)) {		//error handling to check if operand in front invalid
					cout << "you can't use any operand that is not ++, --, or ! in front";
					system("PAUSE");
					exit(1);
				}
				cout << opStack.top();//outputs for whats put in
			}
			else {					//if the next char in the string isn't a operand then just push the string
				string te(1, str[i]);//converting char to a string
				opStack.push(te);	//pushing te (the string we want as an operand into opStack
				if ((opStack.top() != "!") && (i == 0)) {		//if to error handle operands in front
					cout << "you can't use any operand that is not ++, --, or ! in front";
					system("PAUSE");
					exit(1);
				}
				cout << opStack.top();//outputs for whats put in
			}
		}

	}
}

//build function to build stack
//then read stack and do the math

int main() {
	Evaluator eval;		//eval declaration in main
	//eval.evalPostfix();
	eval.build();		//calling the class function build
	cout << endl << endl;//formatting
	int pus;			//var to get the final result
	pus = eval.show();	//final result taken from show function from class eval
	cout << pus;		//output final
	system("PAUSE");	//stops screen to see

	return 0;
}